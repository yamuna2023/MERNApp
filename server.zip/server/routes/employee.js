const express = require('express');
const router = express.Router();
const Employee = require('../models/Employee');

// Define routes for employee

module.exports = router;
