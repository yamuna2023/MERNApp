const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Initialize app
const app = express();

// Middleware
app.use(bodyParser.json());
app.use(cors());

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/mern-app', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Models
const LoginSchema = new mongoose.Schema({
  sno: { type: Number, required: true },
  userName: { type: String, required: true },
  password: { type: String, required: true }
});
const Login = mongoose.model('Login', LoginSchema);

const EmployeeSchema = new mongoose.Schema({
  id: { type: Number, required: true },
  image: { type: String },
  name: { type: String, required: true },
  email: { type: String, required: true },
  mobile: { type: String, required: true },
  designation: { type: String, required: true }
});
const Employee = mongoose.model('Employee', EmployeeSchema);

// Predefined user data
const predefinedUser = {
  sno: 1,
  userName: 'admin',
  password: '$2b$10$D4G5f18oT2Xt7yvM2F6.2e/j.T3u1H5H6ysnO3jTI1v11G9lFk44e' // hashed password for 'password'
};

// Insert predefined user if not exists
const ensurePredefinedUserExists = async () => {
  try {
    let user = await Login.findOne({ userName: predefinedUser.userName });
    if (!user) {
      const newUser = new Login(predefinedUser);
      await newUser.save();
      console.log('Predefined user added');
    }
  } catch (err) {
    console.error('Error checking predefined user:', err);
  }
};
ensurePredefinedUserExists();

// Routes
// User Login
app.post('/api/login', async (req, res) => {
  const { userName, password } = req.body;

  try {
    // Check if user exists
    let user = await Login.findOne({ userName });
    if (!user) {
      return res.status(400).json({ msg: 'Invalid credentials' });
    }

    // Compare password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Invalid credentials' });
    }

    // Return JSON Web Token (JWT)
    const payload = {
      user: {
        id: user.id
      }
    };

    jwt.sign(
      payload,
      'your_jwt_secret',
      { expiresIn: 3600 },
      (err, token) => {
        if (err) throw err;
        res.json({ token });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get All Employees
app.get('/api/employees', async (req, res) => {
  try {
    const employees = await Employee.find();
    res.json(employees);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get Employee by ID
app.get('/api/employees/:id', async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ msg: 'Employee not found' });
    }
    res.json(employee);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Create New Employee
app.post('/api/employees', async (req, res) => {
  const { id, image, name, email, mobile, designation } = req.body;

  try {
    const newEmployee = new Employee({
      id,
      image,
      name,
      email,
      mobile,
      designation
    });

    const employee = await newEmployee.save();
    res.json(employee);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Update Employee
app.put('/api/employees/:id', async (req, res) => {
  const { image, name, email, mobile, designation } = req.body;

  try {
    let employee = await Employee.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ msg: 'Employee not found' });
    }

    employee.image = image || employee.image;
    employee.name = name || employee.name;
    employee.email = email || employee.email;
    employee.mobile = mobile || employee.mobile;
    employee.designation = designation || employee.designation;

    await employee.save();
    res.json(employee);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Delete Employee
app.delete('/api/employees/:id', async (req, res) => {
  try {
    let employee = await Employee.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ msg: 'Employee not found' });
    }

    await employee.remove();
    res.send('Employee removed');
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Start the server
const port = 5000;
app.listen(port, () => console.log(`Server running on port ${port}`));
